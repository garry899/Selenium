package tests;

public class PrintTest {

	public static void main(String[] args) {
		
		System.out.print("Selenium");
		System.out.print("Java");
		System.out.println("Git"); //setting pointer to the next line
		
		System.out.print("Jenkins");
		System.out.println("Junit");//setting pointer to the next line
		
		System.out.print("TestNG");
		System.out.println();//setting pointer to the next line
		System.out.print("Maven");

	}

}
