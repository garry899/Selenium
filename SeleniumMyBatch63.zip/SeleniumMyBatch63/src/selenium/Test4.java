package selenium;

public class Test4 {
	
	public static void audi() {
		System.out.println("audi");
	}
	
	public void bmw() {
		System.out.println("bmw");
	}

}
